export default function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Metode tidak didukung' });
  const hasKey = Boolean(process.env.OPENAI_API_KEY?.trim());
  const hasPass = Boolean(process.env.APP_ACCESS_CODE?.trim());
  return res.status(200).json({
    ready: hasKey && hasPass,
    message: hasKey && hasPass ? 'Server AI siap digunakan.' : 'Server belum aktif: konfigurasi OPENAI_API_KEY dan APP_ACCESS_CODE di Vercel.',
  });
}
